from Robot import Robot
from PepperConfiguration import PepperConfiguration
