from setuptools import find_packages, setup

setup(
    name="pepper",
    package=find_packages()
)
