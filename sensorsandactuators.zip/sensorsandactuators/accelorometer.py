from pepper import Robot, PepperConfiguration


class Accelerometer:
    def __init__(self, robot):
        self.robot = robot

    def run_demo(self):
        pass


if __name__ == '__main__':
    config = PepperConfiguration("Amber")
    robot = Robot(config)
    accelerometer = Accelerometer(robot)
    accelerometer.run_demo()

