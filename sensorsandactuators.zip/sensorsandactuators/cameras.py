from pepper import Robot, PepperConfiguration


class Camera:

    # Add this for a better overview of the camera config
    #    resolutions = {
    #        "40x30": 8,
    #        "80x60": 7,
    #        "160x120": 0,
    #        "320x240": 1,
    #        "640x480": 2,
    #        "1280x960": 3,
    #        "2560x1920": 4
    #    }
    #
    #    formats = {
    #        "bmp" :"bmp",
    #        "dib" :"dib",
    #        "jpeg" :"jpeg",
    #        "jpg" :"jpg",
    #        "jpe" :"jpe",
    #        "png" :"png",
    #        "pbm" :"pbm",
    #        "pgm" :"pgm",
    #        "ppm" :"ppm",
    #        "sr" :"sr",
    #        "ras" :"ras",
    #        "tiff" :"tiff",
    #        "tif" :"tif"
    #    }

    def __init__(self, robot):
        self.robot = robot
        self.camera = robot.ALPhotoCapture
        self.cameras = {
            'top': 0,
            'bottom': 1,
            '3d': 2
        }

    def run_demo(self):
        remote_folder_path = "/home/nao/recordings/cameras/"
        file_name = "picture{}.jpg".format(datetime.now())
        self.camera.setCameraID(self.cameras["top"])
        # use it like this, to also set the resolution and the format
        # self.camera.setResolution(self.formats["jpg"])
        # self.camera.setPictureFormat(self.resolutions[4])
        self.camera.takePicture(remote_folder_path, file_name)


if __name__ == '__main__':
    config = PepperConfiguration("Amber")
    robot = Robot(config)
    cam = Camera(robot)
    cam.run_demo()

