import math
import time

import qi
from pepper import Robot, PepperConfiguration

# Head
MIN_HEAD_PITCH = -0.7068
MAX_HEAD_PITCH = 0.6371
MIN_HEAD_YAW = -2.0857
MAX_HEAD_YAW = 2.0857

# Shoulder Roll
MIN_LEFT_SHOULDER_ROLL = 0.0087
MAX_LEFT_SHOULDER_ROLL = 1.5620
MIN_RIGHT_SHOULDER_ROLL = -0.0087
MAX_RIGHT_SHOULDER_ROLL = -1.5620

# Shoulder Pitch
MIN_SHOULDER_PITCH = -2.0857
MAX_SHOULDER_PITCH = 2.0857

# Elbow Roll(left -, right +)
MIN_LEFT_ELBOW_ROLL = -1.5620
MAX_LEFT_ELBOW_ROLL = -0.0087
MIN_RIGHT_ELBOW_ROLL = 0.0087
MAX_RIGHT_ELBOW_ROLL = 1.5620

# Wrist
MIN_WRIST_YAW = -1.8239
MAX_WRIST_YAW = 1.8239

# Elbow Yaw
MIN_ELBOW_YAW = -2.0857
MAX_ELBOW_YAW = 2.0857

# Hip Pitch back / front
MIN_HIP_PITCH = -1.0385
MAX_HIP_PITCH = 1.0385

# Hip Roll left / right
MIN_HIP_ROLL = -0.5149
MAX_HIP_ROLL = 0.5149

# Knee Pitch back / front
MIN_KNEE_PITCH = -0.5149
MAX_KNEE_PITCH = 0.5149


class Joints:
    def __init__(self, robot, speed):
        self.robot = robot
        self.speed = speed

    def get_angle_degrees(self, name):
        return math.degrees(self.robot.ALMotion.getAngles(name, 0)[0])

    def head_pitch(self):
        self.robot.ALMotion.setAngles("HeadPitch", MIN_HEAD_PITCH, 0.2)
        time.sleep(2)
        self.robot.ALMotion.setAngles("HeadPitch", MAX_HEAD_PITCH, 0.2)
        time.sleep(2)
        self.robot.ALMotion.setAngles("HeadPitch", (MAX_HEAD_PITCH + MIN_HEAD_PITCH) / 2, 0.2)

    def head_yaw(self):
        self.robot.ALMotion.angleInterpolationWithSpeed("HeadYaw", [MIN_HEAD_YAW, MAX_HEAD_YAW], 0.2)
        self.robot.ALMotion.angleInterpolationWithSpeed("HeadYaw", [MAX_HEAD_YAW, MIN_HEAD_YAW], 0.2)

    def shoulder_roll(self):
        self.robot.ALMotion.angleInterpolationWithSpeed(["LShoulderRoll", "RShoulderRoll"],
                                                        [MAX_LEFT_SHOULDER_ROLL, MAX_RIGHT_SHOULDER_ROLL],
                                                        self.speed)

    def shoulder_pitch(self):
        self.robot.ALMotion.angleInterpolationWithSpeed(["LShoulderPitch", "RShoulderPitch"],
                                                        [MAX_SHOULDER_PITCH, MAX_SHOULDER_PITCH],
                                                        self.speed)
        self.robot.ALMotion.angleInterpolationWithSpeed(["LShoulderPitch", "RShoulderPitch"],
                                                        [MIN_SHOULDER_PITCH, MIN_SHOULDER_PITCH],
                                                        self.speed)

    def elbow_roll(self):
        qi.async(self.robot.ALMotion.angleInterpolationWithSpeed,
                 "LElbowRoll",
                 [MAX_LEFT_ELBOW_ROLL, MIN_LEFT_ELBOW_ROLL],
                 self.speed)
        self.robot.ALMotion.angleInterpolationWithSpeed("RElbowRoll",
                                                        [MAX_RIGHT_ELBOW_ROLL, MIN_RIGHT_ELBOW_ROLL],
                                                        self.speed)
        qi.async(self.robot.ALMotion.angleInterpolationWithSpeed,
                 "LElbowRoll",
                 [MIN_LEFT_ELBOW_ROLL, MAX_LEFT_ELBOW_ROLL],
                 self.speed)
        self.robot.ALMotion.angleInterpolationWithSpeed("RElbowRoll",
                                                        [MIN_RIGHT_ELBOW_ROLL, MAX_RIGHT_ELBOW_ROLL],
                                                        self.speed)

    def elbow_yaw(self):
        self.robot.ALMotion.angleInterpolationWithSpeed(["LElbowYaw", "RElbowYaw"],
                                                        [MAX_ELBOW_YAW, MAX_ELBOW_YAW],
                                                        self.speed)
        self.robot.ALMotion.angleInterpolationWithSpeed(["LElbowYaw", "RElbowYaw"],
                                                        [MIN_ELBOW_YAW, MIN_ELBOW_YAW],
                                                        self.speed)

    def close_hand(self, side):
        self.robot.ALMotion.closeHand(side + "Hand")

    def open_hand(self, side):
        self.robot.ALMotion.openHand(side + "Hand")

    def wrist_yaw(self):
        self.robot.ALMotion.angleInterpolationWithSpeed(["LWristYaw", "RWristYaw"],
                                                        [MAX_WRIST_YAW, MAX_WRIST_YAW],
                                                        self.speed)
        self.robot.ALMotion.angleInterpolationWithSpeed(["LWristYaw", "RWristYaw"],
                                                        [MIN_WRIST_YAW, MIN_WRIST_YAW],
                                                        self.speed)
        self.robot.ALMotion.angleInterpolationWithSpeed(["LWristYaw", "RWristYaw"],
                                                        [(MAX_WRIST_YAW + MIN_WRIST_YAW) / 2,
                                                         (MAX_WRIST_YAW + MIN_WRIST_YAW) / 2],
                                                        self.speed)

    def hip_pitch(self):
        self.robot.ALMotion.angleInterpolationWithSpeed("HipPitch", [MIN_HIP_PITCH, MAX_HIP_PITCH], self.speed)
        self.robot.ALMotion.angleInterpolationWithSpeed("HipPitch", [MAX_HIP_PITCH, MIN_HIP_PITCH], self.speed)

    def hip_roll(self):
        self.robot.ALMotion.angleInterpolationWithSpeed("HipRoll", [MIN_HIP_ROLL, MAX_HIP_ROLL], self.speed)
        self.robot.ALMotion.angleInterpolationWithSpeed("HipRoll", [MAX_HIP_ROLL, MIN_HIP_ROLL], self.speed)

    def knee_pitch(self):
        self.robot.ALMotion.angleInterpolationWithSpeed("KneePitch", [MIN_KNEE_PITCH, MAX_KNEE_PITCH], self.speed)
        self.robot.ALMotion.angleInterpolationWithSpeed("KneePitch", [MAX_KNEE_PITCH, MIN_KNEE_PITCH], self.speed)

    def bow(self):
        self.robot.ALRobotPosture.goToPosture("Stand", self.speed)

        qi.async(self.robot.ALMotion.setAngles, "HipPitch", MIN_HIP_PITCH, self.speed)
        qi.async(self.robot.ALMotion.setAngles, "LShoulderRoll", MAX_LEFT_SHOULDER_ROLL, self.speed)
        qi.async(self.robot.ALMotion.setAngles, "LElbowRoll", MAX_LEFT_ELBOW_ROLL, self.speed)
        qi.async(self.robot.ALMotion.setAngles, "LElbowYaw", MIN_ELBOW_YAW, self.speed)
        qi.async(self.robot.ALMotion.setAngles, "RShoulderRoll", 0, self.speed)
        qi.async(self.robot.ALMotion.setAngles, "RShoulderPitch", 0, self.speed)
        self.robot.ALMotion.setAngles("HipPitch", MIN_HIP_PITCH, self.speed)
        time.sleep(1)
        qi.async(self.robot.ALMotion.setAngles, "HeadPitch", 0.1, 0.2)
        qi.async(self.open_hand, "R")
        qi.async(self.open_hand, "L")
        qi.async(self.robot.ALMotion.setAngles, "RWristYaw", 1.6, 0.2)
        qi.async(self.robot.ALMotion.setAngles, "RElbowRoll", MAX_RIGHT_ELBOW_ROLL, self.speed)
        self.robot.ALMotion.setAngles("RElbowYaw", 0, self.speed)

    def run_demo(self):
        self.robot.ALRobotPosture.goToPosture("Stand", self.speed)

        print("head_pitch")
        self.head_pitch()

        print("head_yaw")
        self.head_yaw()
        self.robot.ALRobotPosture.goToPosture("Stand", self.speed)

        print("shoulder_roll")
        self.shoulder_roll()
        time.sleep(1)
        self.robot.ALTextToSpeech.say(
            "My left shoulder is at " + str(self.get_angle_degrees("LShoulderRoll")) + " degrees")
        self.robot.ALRobotPosture.goToPosture("Stand", self.speed)

        print("shoulder_pitch")
        self.shoulder_pitch()
        self.robot.ALRobotPosture.goToPosture("Stand", self.speed)

        self.shoulder_roll()
        print("elbow_roll")
        self.elbow_roll()

        print("elbow_yaw")
        self.elbow_yaw()
        self.robot.ALRobotPosture.goToPosture("StandZero", self.speed)

        print("hands")
        self.open_hand("L")
        self.open_hand("R")

        qi.async(self.close_hand, "L")
        self.close_hand("R")

        print("wrist_yaw")
        self.wrist_yaw()

        self.robot.ALRobotPosture.goToPosture("Stand", self.speed)
        print("hip_pitch")
        self.hip_pitch()

        time.sleep(1)
        self.robot.ALRobotPosture.goToPosture("Stand", self.speed)
        print("hip_roll")
        self.hip_roll()

        time.sleep(1)
        self.robot.ALRobotPosture.goToPosture("Stand", self.speed)
        print("knee_pitch")
        self.knee_pitch()

        self.robot.ALRobotPosture.goToPosture("Stand", self.speed)

        self.bow()

        time.sleep(5)

        self.robot.ALRobotPosture.goToPosture("Stand", self.speed)


if __name__ == '__main__':
    port = 52352
    config = PepperConfiguration("simulated_robot", "localhost", port)

    # config = PepperConfiguration("Porter")

    robot = Robot(config)
    joints = Joints(robot, 0.5)

    org_state = robot.ALAutonomousLife.getState()
    robot.ALAutonomousLife.setState("disabled")

    joints.run_demo()

    robot.ALAutonomousLife.setState(org_state)
