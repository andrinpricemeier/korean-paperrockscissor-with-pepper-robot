import math
import qi

# Porter
ipaddress = "192.168.1.102"
port = 9559


def connect_to_pepper(ip, port):
	connection_url = ip + ":" + str(port)
	app = qi.Application(["--qi-url=" + connection_url])
	app.start()
	return app.session


def laser_front(session):
	memory = session.service("ALMemory")
	laser_values = []
	for i in range(1, 16):
		seg = str(i).zfill(2)
		
		x = memory.getData("Device/SubDeviceList/Platform/LaserSensor/Front/Horizontal/Seg" + seg + "/X/Sensor/Value")
		y = memory.getData("Device/SubDeviceList/Platform/LaserSensor/Front/Horizontal/Seg" + seg + "/Y/Sensor/Value")
		laser_values.append(math.sqrt(x ** 2 + y ** 2))
	
	return min(laser_values)


def laser_left(session):
	memory = session.service("ALMemory")
	laser_values = []
	for i in range(1, 16):
		seg = str(i).zfill(2)
		
		x = memory.getData("Device/SubDeviceList/Platform/LaserSensor/Left/Horizontal/Seg" + seg + "/X/Sensor/Value")
		y = memory.getData("Device/SubDeviceList/Platform/LaserSensor/Left/Horizontal/Seg" + seg + "/Y/Sensor/Value")
		laser_values.append(math.sqrt(x ** 2 + y ** 2))
	
	return min(laser_values)


def laser_right(session):
	memory = session.service("ALMemory")
	laser_values = []
	for i in range(1, 16):
		seg = str(i).zfill(2)
		
		x = memory.getData("Device/SubDeviceList/Platform/LaserSensor/Right/Horizontal/Seg" + seg + "/X/Sensor/Value")
		y = memory.getData("Device/SubDeviceList/Platform/LaserSensor/Right/Horizontal/Seg" + seg + "/Y/Sensor/Value")
		laser_values.append(math.sqrt(x ** 2 + y ** 2))
	
	return min(laser_values)


def laser_shovel(session):
	memory = session.service("ALMemory")
	laser_values = []
	for i in range(1, 4):
		seg = str(i).zfill(2)
		
		x = memory.getData("Device/SubDeviceList/Platform/LaserSensor/Front/Shovel/Seg" + seg + "/X/Sensor/Value")
		y = memory.getData("Device/SubDeviceList/Platform/LaserSensor/Front/Shovel/Seg" + seg + "/Y/Sensor/Value")
		laser_values.append(math.sqrt(x ** 2 + y ** 2))
	
	return min(laser_values)


def laser_front_left(session):
	memory = session.service("ALMemory")
	
	x = memory.getData("Device/SubDeviceList/Platform/LaserSensor/Front/Vertical/Left/Seg01/X/Sensor/Value")
	y = memory.getData("Device/SubDeviceList/Platform/LaserSensor/Front/Vertical/Left/Seg01/Y/Sensor/Value")
	
	return math.sqrt(x ** 2 + y ** 2)


def laser_front_right(session):
	memory = session.service("ALMemory")
	
	x = memory.getData("Device/SubDeviceList/Platform/LaserSensor/Front/Vertical/Right/Seg01/X/Sensor/Value")
	y = memory.getData("Device/SubDeviceList/Platform/LaserSensor/Front/Vertical/Right/Seg01/Y/Sensor/Value")
	
	return math.sqrt(x ** 2 + y ** 2)


if __name__ == '__main__':
	session = connect_to_pepper("192.168.1.102", 9559)
	print("Front: {}".format(laser_front(session)))
	print("Left: {}".format(laser_left(session)))
	print("Right: {}".format(laser_right(session)))
	print("Shovel: {}".format(laser_shovel(session)))
	print("Front Left: {}".format(laser_front_left(session)))
	print("Front Right: {}".format(laser_front_right(session)))
