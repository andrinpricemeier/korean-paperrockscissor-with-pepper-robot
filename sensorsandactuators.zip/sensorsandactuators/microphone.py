import time
import qi
import sys
from pepper import Robot, PepperConfiguration

class Microphone:
    def __init__(self, robot):
        self.robot = robot
        self._start = False
        self._stop = False
        self._greeted = False
        memory = robot.session.service("ALMemory")
        self.subscriber = memory.subscriber('WordRecognized')
        self.subscriber.signal.connect(self.__speech_callback)
        self.__speech_recognition = robot.session.service("ALSpeechRecognition")
        self.__speech_recognition.pause(True)
        self.__speech_recognition.setLanguage("English")
        vocab = ["yes", "no", "hello", "bye", "what's up", "good"]
        self.__speech_recognition.setVocabulary(vocab, True)
        self.__speech_recognition.pause(False)
        self.__speech_recognition.subscribe("SpeechDetection")
        print('Speech Recognition Engine Started')

    def __speech_callback(self, value):
        print('Recognized the following words '+ value[0] + ' with accuracy ' + str(value[1]))
        if 'hello' in value[0]:
            if value[1] > 0.50:
                print('Greeting recognized')
                print(value[0])
                self._greeted = True
        if 'yes' in value[0]:
            if value[1] > 0.50:
                self.robot.ALTextToSpeech.say("Ok playing music now")
                self.robot.ALAudioPlayer.playFileFromPosition('/home/nao/group02/beautifulmusic.wav', position=210)
        if 'no' in value[0]:
            if value[1] > 0.50:
                self.robot.ALTextToSpeech.say('Oh ok')
                self.robot.ALAudioPlayer.stopAll()   # maybe works maybe not -> find workaround
        if 'bye' in value[0]:
            if value[1] > 0.50:
                self.robot.ALTextToSpeech.say("Ok goodbye. Hope you have a nice day")
        if "what's up" in value[0]:
            if value[1] > 0.50:
                self.robot.ALTextToSpeech.say("Not much how about you?")
        if 'good' in value[0]:
            if value[1] > 0.50:
                self.robot.ALTextToSpeech.say("That's good to hear.")


    def run_demo(self):
        counter = 0
        print("===========  Running Text to speech demo =============")
        while not self._stop and counter < 30:
            print "iteration " + str(counter)
            if self._start:
                # Play song
                self._start = False
                print "starting"
            if self._greeted:
                self.robot.ALTextToSpeech.setLanguage("English")
                self.robot.ALTextToSpeech.say("Hello All")
                self.robot.ALTextToSpeech.say("Would you like to hear a song?")
                self._greeted = False
            time.sleep(1)
            counter += 1
        self.__speech_recognition.unsubscribe("SpeechDetection")
        print('Speech recognition engine stopped')

if __name__ == '__main__':
    config = PepperConfiguration("Pale")
    robot = Robot(config)
    mic = Microphone(robot)
    mic.run_demo()


