import qi

# Porter
ipaddress = "192.168.1.102"
port = 9559


def connect_to_pepper(ip, port):
	connection_url = ip + ":" + str(port)
	app = qi.Application(["--qi-url=" + connection_url])
	app.start()
	return app.session


def get_sonar_range(session):
	# connect to sonarservice
	sonar_force_connect = session.service("ALSonar")
	# connect to memory
	memory_force_connect = session.service("ALMemory")
	
	# subscribe to sonar. Subscribes to the extractor. This causes the extractor to start writing information to
	# memory using the keys described by getOutputNames(). These can be accessed in memory using
	# ALMemory.getData("keyName").
	sonar_force_connect.subscribe("anyName")
	
	# http://doc.aldebaran.com/2-0/family/juliette_technical/juliette_dcm/actuator_sensor_names.html#sonars
	front = memory_force_connect.getData("Device/SubDeviceList/Platform/Front/Sonar/Sensor/Value")
	back = memory_force_connect.getData("Device/SubDeviceList/Platform/Back/Sonar/Sensor/Value")
	
	return front, back


if __name__ == '__main__':
	session = connect_to_pepper("192.168.1.102", 9559)
	print("Sonar Front, Back: {}".format(get_sonar_range(session)))
