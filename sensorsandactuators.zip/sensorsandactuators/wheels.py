import time

from pepper import PepperConfiguration, Robot


class WheelsDemo():
    def __init__(self):
        self.config = PepperConfiguration("Porter")
        robot = Robot(self.config)
        self.motion = robot.ALMotion

        if robot.ALAutonomousLife.getState() != "disabled":
            robot.ALAutonomousLife.setState("disabled")

        robot.ALRobotPosture.goToPosture("Stand", 0.8)

    def move(self):
        """Makes the robot move at the given speed in S.I. units. This is a blocking call.

        :param float x: The speed along x axis [m.s-1].
        :param float y: The speed along y axis [m.s-1].
        :param float theta: The anglular speed around z axis [rad.s-1].
        """
        self.motion.move(0.55, 0, 0)
        time.sleep(1)
        self.motion.move(-0.55, 0, 0)
        time.sleep(1)
        self.motion.move(0, -0.5, 0)
        time.sleep(1)
        self.motion.move(0, 0.5, 0)
        time.sleep(1)
        self.motion.move(0, 0, 3.142)
        time.sleep(1)
        self.motion.move(0, 0, -3.142)

    def moveTo(self):
        """Makes the robot move at the given position.This is a blocking call.

        :param float x: The position along x axis [m].
        :param float y: The position along y axis [m].
        :param float theta: The angle around z axis [rad].
        """
        self.motion.moveTo(1.0, 0, 0)
        time.sleep(1)
        self.motion.moveTo(-1.0, 0, 0)
        time.sleep(1)
        self.motion.moveTo(0, -0.5, 0)
        time.sleep(1)
        self.motion.moveTo(0, 0.5, 0)
        time.sleep(1)
        self.motion.moveTo(0, 0, 3.142)
        time.sleep(1)
        self.motion.moveTo(0, 0, -3.142)

    def moveTowards(self):
        """Makes the robot move at the given normalized velocity. This is a non-blocking call.

        :param float x: The normalized velocity along x axis (between -1 and 1).
        :param float y: The normalized velocity along y axis (between -1 and 1).
        :param float theta: The normalized velocity around z axis (between -1 and 1).
        """
        self.motion.moveToward(0.2, 0.2, 0)
        time.sleep(1)
        self.motion.moveToward(-0.2, 0.2, 0)
        time.sleep(1)
        self.motion.moveToward(1, 0, 0)
        time.sleep(1)
        self.motion.moveToward(1, 0.5, 0)
        time.sleep(1)
        self.motion.moveToward(0, 0, 1)


if __name__ == '__main__':
    wheelsDemo = WheelsDemo()
    wheelsDemo.move()
    # wheelsDemo.moveTo()
    # wheelsDemo.moveTowards()
